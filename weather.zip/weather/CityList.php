<?php
class CityList {
	// http://webservice.webxml.com.cn/WebServices/WeatherWS.asmx
	// 获得中国省份、直辖市、地区和与之对应的ID的URL
	private $_regionProvince = 'http://webservice.webxml.com.cn/WebServices/WeatherWS.asmx/getRegionProvince';
	
	// 获得支持的城市/地区名称和与之对应的ID的URL
	private $_supportCityString = 'http://webservice.webxml.com.cn/WebServices/WeatherWS.asmx/getSupportCityString';
	
	/**
	 * 获取省份，直辖市
	 */
	public function getRegionProvinces() {
		$result_xml = file_get_contents ( $this->_regionProvince );
		return simplexml_load_string ( $result_xml );
	}
	/**
	 * 生成城市缓存文件
	 */
	public function getSupportCityString() {
		$provinces = $this->getRegionProvinces ();
		
		$city_list = array();
		
		foreach ( $provinces as $ky => $province ) {
			$province_array = preg_split('/,/', $province);
			$post = array ();
			$post ['theRegionCode'] = $province_array[0];			
			$city_list[md5($province_array[0])] = $province_array;			
			$result_xml_string = self::post ( $this->_supportCityString, $post );			
			$result_xml_dom = simplexml_load_string ( $result_xml_string );
			foreach ($result_xml_dom as $city_index=>$city){
				$city_array = preg_split('/,/', $city);
				$city_list[md5($city_array[0])] = $city_array; 
			}
		}
		file_put_contents(dirname(__FILE__).'/CityArray.php', '<?php return '.var_export($city_list,true).';');
		echo count($city_list);
		exit ();
	}
	/**
	 * 
	 * @param unknown_type $url
	 * @param unknown_type $post
	 */
	static function post($url, $post = null) {
		$context = array ();
		if (is_array ( $post )) {
			ksort ( $post );
			$context ['http'] = array (
					'method' => 'POST',
					//'header'=>"Accept-language: en\r\n" . "Cookie: foo=bar\r\n",		
					'header'=>"Content-Type:application/x-www-form-urlencoded\r\n"."User-Agent:Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.4 (KHTML, like Gecko) Chrome/22.0.1229.92 Safari/537.4\r\n",
					'content' => http_build_query ( $post, '', '&' ) 
			);
		}
		return file_get_contents ( $url, false, stream_context_create ( $context ) );
	}

}
//$instance = new CityList ();
//echo $instance->getSupportCityString ();