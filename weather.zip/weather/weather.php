<?php
	header("Content-type: text/xml;charset=utf-8");

	define('CACHE_DATA_PATH', dirname(__FILE__) . '/cache/');   // 远特天气接口返回结果缓存文件夹
	define('AP_PRIVATE_DATA_PATH', dirname(__FILE__) . '/cache/');   // 第三方天气结果缓存文件夹
	define('WEBXML_CN_KEY','d54489705e044cce9832dfd6a0619829');	// WEBXML接口key
	
	include_once 'WeatherWebxml.php';
	include_once 'CityList.php';
	include_once 'xml_func.php';
    
	
    $cityname = $_GET['city'];
	$v = $_GET['v'];
   
    switch ($cityname){
		case 'chongqing' :$cityname = '重庆'; break;
		case 'zhengjiang' :$cityname = '镇江'; break;
		case 'zhanjiang' :$cityname = '湛江'; break;
		case 'jiangmen' :$cityname = '江门'; break;
		case 'mudanjiang' :$cityname = '牡丹江'; break;
		case 'xiangyang' :$cityname = '襄阳'; break;
		case 'macau' :$cityname = '澳门'; break;
	}
	
	// 特殊城市转换，此类城市没有天气数据，转换为附近有天气的城市
	$cityReplace = '';
	if($cityname == '乌兰察布') {
		$cityname = '集宁';
		$cityReplace = '乌兰察布';
	} else if($cityname == '荷泽') {
		$cityname = '菏泽';
		$cityReplace = '荷泽';
	} else if($cityname == '呼伦贝尔') {
		$cityname = '海拉尔';
		$cityReplace = '呼伦贝尔';
	}
	
	
	if ($v == '2') {
		$content = getWeather($cityname);
		
		if(strlen($cityReplace) > 0) {
			$content = str_replace($cityname,$cityReplace,$content);
		}
		
		echo $content;
		exit();
	} else {
		$absCacheFile = AP_PRIVATE_DATA_PATH . md5($cityname) . '.xml';
		$mtime = @filemtime($absCacheFile);
		$filesize = @filesize($absCacheFile);
		if (mktime() - $mtime > 7200 || $filesize < 300 || !file_exists($absCacheFile)) {
			$dom = new DOMdocument("1.0", "utf-8");
			$dom->formatOutput = true;
			$root = appendXmlNode($dom, $dom, 'weather');
			crtWeatherData($dom, $root, $cityname);
			$strResult = $dom->saveXML();
			
			//$strResult = str_replace('xiangyang', '襄阳', $strResult);
			if(strlen($cityReplace) > 0) {
				$strResult = str_replace($cityname,$cityReplace,$strResult);
			}
			
			@file_put_contents($absCacheFile, $strResult);
			echo $strResult;
			exit();
		}
		$content = @file_get_contents($absCacheFile);
		//$content = str_replace('xiangyang', '襄阳', $content);
		
		if(strlen($cityReplace) > 0) {
			$content = str_replace($cityname,$cityReplace,$content);
		}
		
		echo $content;
		exit();
	}
	
	
	
	
	
	
	
	/**
     * 
     * 以下是新的天气接口
     * @param string $rCityName
     * @param string $outPut
     */
    function getWeather ($rCityName, $outPut = 'xml')
    {
        $absCacheFile = CACHE_DATA_PATH . md5($rCityName) . '2.xml';
       
        $filesize = @filesize($absCacheFile);
        if (file_exists($absCacheFile) && (time()-filemtime($absCacheFile)) < 7200 && $filesize > 300) {
            $weather = file_get_contents($absCacheFile);
        } else {
            $weather = WeatherWebxml::getInstance()->getWeather($rCityName);
                         
            $xml = returnXml($weather);
	        file_put_contents($absCacheFile, $xml); 
        }
        switch ($outPut) {
            case 'xml':
                if (is_array($weather)) {
                    $weather = returnXml($weather);
                }
                break;
            case 'array':
                if (is_string($weather)) {
                    $weather = xmlToArray($weather);
                }
                break;
        }
        return $weather;
    }
	
	
	/**
     * 
     * 以下是新的天气接口
     * @param unknown_type $weather
     */
    function returnXml($weather)
    {
    	//去掉单位
    	$weather['today_conditions']['temp_c']['low'] = str_replace("℃", "", $weather['today_conditions']['temp_c']['low']);
    	$weather['today_conditions']['temp_c']['high'] = str_replace("℃", "", $weather['today_conditions']['temp_c']['high']);
    	$weather['today_conditions']['temp_c']['now'] = str_replace("℃", "", $weather['today_conditions']['temp_c']['now']);
    	$weather['tomorrow_conditions']['temp_c']['low'] = str_replace("℃", "", $weather['tomorrow_conditions']['temp_c']['low']);
    	$weather['tomorrow_conditions']['temp_c']['high'] = str_replace("℃", "", $weather['tomorrow_conditions']['temp_c']['high']);
    	$weather['after_tomorrow_conditions']['temp_c']['low'] = str_replace("℃", "", $weather['after_tomorrow_conditions']['temp_c']['low']);
    	$weather['after_tomorrow_conditions']['temp_c']['high'] = str_replace("℃", "", $weather['after_tomorrow_conditions']['temp_c']['high']);
    	
    	$br = PHP_EOL;
    	
    	$xml = '<?xml version="1.0" encoding="utf-8"?>'.$br;
		$xml .= '<weather>'.$br;
  		$xml .= '<city_name>'.$weather['city_name'].'</city_name>'.$br;
        $xml .= '<today_conditions>'.$br;
        $xml .= '<condition data="'.formatXmlSpecialChar($weather['today_conditions']['condition']).'" weather_type="'.$weather['today_conditions']['weather_type'].'" icon_uri="'.formatXmlSpecialChar($weather['today_conditions']['icon_uri']).'"/> '.$br;
        $xml .= '<temp_c low="'.$weather['today_conditions']['temp_c']['low'].'" high="'.$weather['today_conditions']['temp_c']['high'].'" now="'.$weather['today_conditions']['temp_c']['now'].'"/>'.$br;
        //$xml .= '<forecast_date data="'.$weather['today_conditions']['forecast'].'"/>';
        //使用系统当前日期
        $xml .= '<forecast_date data="'.date('Y-m-d',mktime()).'"/>'.$br;
        $xml .= '<current_date_time data="'.$weather['today_conditions']['current_date_time'].'"/>'.$br;
        $xml .= '<humidity data="'.$weather['today_conditions']['humidity'].'"/>'.$br;
        $xml .= '<wind_condition direction="'.formatXmlSpecialChar($weather['today_conditions']['wind_condition']['direction']).'" power="'.$weather['today_conditions']['wind_condition']['power'].'"/>'.$br;
        $xml .= '<washcar_condition data="'.formatXmlSpecialChar($weather['today_conditions']['washcar_condition']['data']).'" desc="'.formatXmlSpecialChar($weather['today_conditions']['washcar_condition']['desc']).'"/>'.$br;
        $xml .= '</today_conditions>'.$br;
        $xml .= '<tomorrow_conditions>'.$br;
        $xml .= '<condition data="'.formatXmlSpecialChar($weather['tomorrow_conditions']['condition']).'" weather_type="'.$weather['tomorrow_conditions']['weather_type'].'" icon_uri="'.formatXmlSpecialChar($weather['tomorrow_conditions']['icon_uri']).'"/>'.$br;
	    $xml .= '<temp_c low="'.$weather['tomorrow_conditions']['temp_c']['low'].'" high="'.$weather['tomorrow_conditions']['temp_c']['high'].'"/> '.$br;
	    $xml .= '<wind_condition direction="'.$weather['tomorrow_conditions']['wind_condition']['direction'].'" power="'.$weather['tomorrow_conditions']['wind_condition']['power'].'"/> '.$br;
	    $xml .= '<washcar_condition data="'.formatXmlSpecialChar($weather['tomorrow_conditions']['washcar_condition']['data']).'" desc="'.formatXmlSpecialChar($weather['tomorrow_conditions']['washcar_condition']['desc']).'"/>'.$br;
	    $xml .= '</tomorrow_conditions>'.$br;
	    $xml .= '<after_tomorrow_conditions>'.$br;
	    $xml .= '<condition data="'.formatXmlSpecialChar($weather['after_tomorrow_conditions']['condition']).'" weather_type="'.$weather['after_tomorrow_conditions']['weather_type'].'" icon_uri="'.formatXmlSpecialChar($weather['after_tomorrow_conditions']['icon_uri']).'"/>'.$br;
	    $xml .= '<temp_c low="'.$weather['after_tomorrow_conditions']['temp_c']['low'].'" high="'.$weather['after_tomorrow_conditions']['temp_c']['high'].'"/>'.$br;
	    $xml .= '<wind_condition direction="'.formatXmlSpecialChar($weather['after_tomorrow_conditions']['wind_condition']['direction']).'" power="'.formatXmlSpecialChar($weather['after_tomorrow_conditions']['wind_condition']['power']).'"/>'.$br;
	    $xml .= '<washcar_condition data="'.formatXmlSpecialChar($weather['after_tomorrow_conditions']['washcar_condition']['data']).'" desc="'.formatXmlSpecialChar($weather['after_tomorrow_conditions']['washcar_condition']['desc']).'"/>'.$br;
	    $xml .= '</after_tomorrow_conditions>'.$br;
	    $xml .= '</weather>';
	    return $xml;
    }
	
	/**
     * 
     * 以下是新的天气接口
     * @param unknown_type $objects
     */
    function xmlToArray ($objects)
    {
        $array = array();
        $objects = (array) $objects;
        foreach ($objects as $key => $object) {
            if ($object instanceof SimpleXMLElement || is_array($object)) {
                $object = xmlToArray($object);
            }
            $array = array_merge($array, array($key => $object));
        }
        return $array;
    }
	
	/**
     * 老接口，以下联动的相关函数到web使用的为止，都是老接口使用的
     * 
     * @param unknown_type $dom         a
     * @param unknown_type $weatherNode a
     * @param unknown_type $cityname    a
     * 
     * @return return_type
     */
    function crtWeatherData ($dom, $weatherNode, $cityname = '')
    {
		//终端拥有的图标
		$_kind_of_weather = array(
			'sunny'=>'0',
			'mostly_sunny'=>'0',
			'partly_cloudy'=>'1',
			'cloudy'=>'1',
			'mostly_cloudy'=>'1',
			'rain'=>'3',
			'chance_of_rain'=>'3',
			'storm'=>'4',
			'chance_of_storm'=>'4',
			'thunderstorm'=>'4',
			'chance_of_tstorm'=>'4',
			'snow'=>'15',
			'sleet'=>'17',
			'chance_of_snow'=>'13',
			'flurries'=>'14',
			'icy'=>'28',
			'mist'=>'18',
			'fog'=>'18',
			'haze'=>'18',
			'smoke'=>'29',
			'dust'=>'20',
			'cn_heavyrain'=>'22',
			'cn_cloudy'=>'1',
		);

		/**简单修复了历史版本的 weather_type和$_kind_of_weather的反向对应查询*/
		$_kind_of_weather_fix = array(         
			'10'=>'thunderstorm', 
		);
		//修改图片和weather_type为空混乱问题
		$_web_service_kind = array(
			'0' =>'1',
			'1' =>'3',
			'2' => '4',
			'3' => '3',
			'4' => '22',
			'5' => '13',
			'6' => '15',
			'7' => '22',
			'8' => '3',
			'9' => '3',
			'10'=> '22',
			'11'=> '22',
			'12'=> '22',
			'13'=> '14',
			'14'=> '15',
			'15'=> '22',
			'16'=> '22',
			'17'=> '22',
			'18'=> '18',
			'19'=> '3',
			'20'=> '3',
			'21'=> '3',
			'22'=> '3',
			'23'=> '3',
			'24'=> '3',
			'25'=> '3',
			'26'=> '22',
			'27'=> '22',
			'28'=> '22',
			'29'=> '3',
			'30'=> '3',
			'31'=> '3',
		);
		
		$_gaode_weather_type_desc = array(
			'晴'=>'0',
			'多云'=>'1',
			'阴'=>'1',
			'阵雨'=>'3',
			'雷阵雨'=>'3',
			'雨夹雪'=>'17',
			'小雨'=>'3',
			'中雨'=>'3',
			'大雨'=>'3',
			'暴雨'=>'22',
			'大暴雨'=>'4',
			'阵雪'=>'15',
			'小雪'=>'15',
			'中雪'=>'15',
			'大雪'=>'15',
			'暴雪'=>'15',
			'轻雾'=>'18',
			'浓雾'=>'18',
			'雾'=>'18',
			'冻雨'=>'17',
			'沙尘暴'=>'18',
			'浮尘'=>'18',
			'扬沙'=>'18',
			'冰雹'=>'17',
			'强沙尘暴'=>'18',
			'霾'=>'18',
			'烟'=>'18',
			'霜冻'=>'28',
		);
	
    	$cityname = str_replace('市', '', $cityname);
    	
        $weather = WeatherWebxml::getInstance()->getWeather($cityname);
       
        $city_node = appendXmlNode($dom, $weatherNode, 'city_name');
        $city_node->appendChild(
        		$dom->createTextNode($weather ['city_name'])
        );
        //$cityname = UrlEncode($cityname);
        $today_conditions = appendXmlNode($dom, $weatherNode, 'today_conditions');
        $tomorrow_conditions = appendXmlNode(
        		$dom, $weatherNode, 'tomorrow_conditions'
        );
        $after_tomorrow_conditions = appendXmlNode(
        		$dom, $weatherNode, 'after_tomorrow_conditions'
        );
        
        //var_dump($weather);exit;
		$tmpNode = appendXmlNode($dom, $today_conditions, 'condition');
             
        setXmlNodeAttribute($dom, $tmpNode, 'data', $weather ['today_conditions'] ['condition']); 
        setXmlNodeAttribute($dom, $tmpNode, 'weather_type', 
			$_web_service_kind[$weather ['today_conditions'] ['weather_type']]
		);
      	//旧版本备用天气接口图标讲数组反转成字符文件
       	//老版本采用uri来显示图标，这里需要设置图片
       	$_ico_file_key = $_web_service_kind[$weather ['today_conditions'] ['weather_type']];            
        $_file_name='';
        
        foreach ( $_kind_of_weather as $key => $value ) {
        	if ($value == $_ico_file_key) {
        		$_file_name = $key;
        		break;
        	}
        }
        
        $_ico_base_url = 'http://www.google.com/ig/images/weather/';
        $_ico_url = empty ( $_file_name ) ? '' : $_ico_base_url . $_file_name . '.gif';
        //
        setXmlNodeAttribute ( $dom, $tmpNode, 'icon_uri', $_ico_url );
        $tmpNode = appendXmlNode ( $dom, $today_conditions, 'temp_c' );
        
         
        setXmlNodeAttribute ( $dom, $tmpNode, 'low', $weather ['today_conditions'] ['temp_c'] ['low'] );
        setXmlNodeAttribute ( $dom, $tmpNode, 'high', $weather ['today_conditions'] ['temp_c'] ['high'] ); 
        setXmlNodeAttribute ( $dom, $tmpNode, 'now', $weather ['today_conditions'] ['temp_c'] ['now'] );
        
        $tmpNode = appendXmlNode ( $dom, $today_conditions, 'forecast_date' );        
        // 采用当前系统时间
        setXmlNodeAttribute ( $dom, $tmpNode, 'data', date ( 'Y-m-d', mktime () ) );
        
        $tmpNode = appendXmlNode ( $dom, $today_conditions, 'current_date_time' );
        setXmlNodeAttribute ( $dom, $tmpNode, 'data', $weather ['today_conditions'] ['current_date_time'] );
        
        $tmpNode = appendXmlNode ( $dom, $today_conditions, 'humidity' );
        setXmlNodeAttribute ( $dom, $tmpNode, 'data', $weather ['today_conditions'] ['humidity'] );
        
        $tmpNode = appendXmlNode ( $dom, $today_conditions, 'wind_condition' );   
        setXmlNodeAttribute ( $dom, $tmpNode, 'direction', $weather ['today_conditions'] ['wind_condition'] ['direction'] );
        setXmlNodeAttribute ( $dom, $tmpNode, 'power', '' );
        
        
        $tmpNode = appendXmlNode ( $dom, $today_conditions, 'washcar_condition' );
        setXmlNodeAttribute ( $dom, $tmpNode, 'data', $weather ['today_conditions'] ['washcar_condition'] ['data'] );
        setXmlNodeAttribute ( $dom, $tmpNode, 'desc', $weather ['today_conditions'] ['washcar_condition'] ['desc'] );
        
        // 明天天气
        $tmpNode = appendXmlNode ( $dom, $tomorrow_conditions, 'condition' );
        setXmlNodeAttribute ( $dom, $tmpNode, 'data', $weather ['tomorrow_conditions'] ['condition'] );        
        setXmlNodeAttribute ( $dom, $tmpNode, 'weather_type', $_web_service_kind [$weather ['tomorrow_conditions'] ['weather_type']] );
      
        // 旧版本备用天气接口图标讲数组反转成字符文件
        // 老版本采用uri来显示图标，这里需要设置图片
        $_ico_file_key = $_web_service_kind [$weather ['tomorrow_conditions'] ['weather_type']];
        $_file_name = '';
        foreach ( $_kind_of_weather as $key => $value ) {
        	if ($value == $_ico_file_key) {
        		$_file_name = $key;
        		break;
        	}
        }
        $_ico_base_url = 'http://www.google.com/ig/images/weather/';
        $_ico_url = empty ( $_file_name ) ? '' : $_ico_base_url . $_file_name . '.gif';
        //
        setXmlNodeAttribute ( $dom, $tmpNode, 'icon_uri', $_ico_url );
        
        $tmpNode = appendXmlNode ( $dom, $tomorrow_conditions, 'temp_c' );
        
        setXmlNodeAttribute ( $dom, $tmpNode, 'low', $weather ['tomorrow_conditions'] ['temp_c'] ['low'] );
        setXmlNodeAttribute ( $dom, $tmpNode, 'high', $weather ['tomorrow_conditions'] ['temp_c'] ['high'] );
       
        $tmpNode = appendXmlNode ( $dom, $tomorrow_conditions, 'wind_condition' );
        setXmlNodeAttribute ( $dom, $tmpNode, 'direction', $weather ['tomorrow_conditions'] ['wind_condition'] ['direction'] );
        setXmlNodeAttribute ( $dom, $tmpNode, 'power', '' );
        
        $tmpNode = appendXmlNode ( $dom, $tomorrow_conditions, 'washcar_condition' );
        setXmlNodeAttribute ( $dom, $tmpNode, 'data', '' );
        setXmlNodeAttribute ( $dom, $tmpNode, 'desc', '' );
       
        // 后天天气
        $tmpNode = appendXmlNode ( $dom, $after_tomorrow_conditions, 'condition' );
        setXmlNodeAttribute ( $dom, $tmpNode, 'data', $weather ['after_tomorrow_conditions'] ['condition'] );

        setXmlNodeAttribute ( $dom, $tmpNode, 'weather_type', $_web_service_kind [$weather ['after_tomorrow_conditions'] ['weather_type']] );
        
        // 旧版本备用天气接口图标讲数组反转成字符文件
        // 老版本采用uri来显示图标，这里需要设置图片
        $_ico_file_key = $_web_service_kind [$weather ['after_tomorrow_conditions'] ['weather_type']];
        $_file_name = '';
        foreach ( $_kind_of_weather as $key => $value ) {
        	if ($value == $_ico_file_key) {
        		$_file_name = $key;
        		break;
        	}
        }
        $_ico_base_url = 'http://www.google.com/ig/images/weather/';
        $_ico_url = empty ( $_file_name ) ? '' : $_ico_base_url . $_file_name . '.gif';
        //
        setXmlNodeAttribute ( $dom, $tmpNode, 'icon_uri', $_ico_url );
        
        $tmpNode = appendXmlNode ( $dom, $after_tomorrow_conditions, 'temp_c' );
        
        setXmlNodeAttribute ( $dom, $tmpNode, 'low', $weather ['after_tomorrow_conditions'] ['temp_c'] ['low'] );
        setXmlNodeAttribute ( $dom, $tmpNode, 'high', $weather ['after_tomorrow_conditions'] ['temp_c'] ['high'] );
        
        $tmpNode = appendXmlNode ( $dom, $after_tomorrow_conditions, 'wind_condition' );
        @setXmlNodeAttribute ( $dom, $tmpNode, 'direction', $weather ['after_tomorrow_conditions'] ['wind_condition']['direction'] );
        setXmlNodeAttribute ( $dom, $tmpNode, 'power', '' );
        
        $tmpNode = appendXmlNode ( $dom, $after_tomorrow_conditions, 'washcar_condition' );
        setXmlNodeAttribute ( $dom, $tmpNode, 'data', '' );
        setXmlNodeAttribute ( $dom, $tmpNode, 'desc', '' );
    }