<?php

class WeatherWebxml {
	private static $_instance = null;
	private static $_cityList = array();
	public static function getInstance(){
		if(self::$_instance==null){
			self::$_cityList = include dirname ( __FILE__ ) . '/CityArray.php';
			return new self();
		}
		return self::$_instance;
	}
	/**
	 * 从第三方获取数据天气xml数据
	 * @param unknown_type $rCityName
	 * @return string
	 */
	function getWeatherXml($rCityName){
		$city_name = md5($rCityName);
		$absCacheFile = AP_PRIVATE_DATA_PATH . $city_name . '_rawdata.xml';
		$mtime = @filemtime($absCacheFile);
		$filesize = @filesize($absCacheFile);
		
		if (!file_exists($absCacheFile) || mktime() - $mtime > 21600 || $filesize<300 ) {
			$post = array ();
			if(!isset(self::$_cityList[$city_name])){
				$post ['theCityCode'] = '792';
				$post ['theUserID'] = WEBXML_CN_KEY;
			}else{
				$temp_city_list = self::$_cityList[$city_name];
				$post ['theCityCode'] = $temp_city_list[1];
				$post ['theUserID'] = WEBXML_CN_KEY;
			}
			$weather = array ();
			
			// 2015-12-14 modify 更换性能更好的接口地址webservice开头的域名换为st1
			
			$url = 'http://st1.webxml.com.cn/WebServices/WeatherWS.asmx/getWeather';
			$content = CityList::post ( $url, $post );
			
			//写入缓存文件
			if(strlen($content) > 300){
				@file_put_contents($absCacheFile, $content);
			}
		}else{
			$content = @file_get_contents($absCacheFile);
		}
		
		return $content;
	}
	
	
	/**
	 * 根据天气描述匹配最接近的天气图标，用于解决无天气图标或天气描述不规则的情况
	 *
	 * @param string $strCondition 天气描述        	
	 */
	function getWeatherTypeFromDesc($strCondition) {
		if(!(strpos($strCondition,'晴') === false)) {
			return 0;
		} else if(!(strpos($strCondition,'多云') === false)) {
			return 1;
		} else if(!(strpos($strCondition,'阴') === false)) {
			return 2;
		} else if(!(strpos($strCondition,'雨') === false)) {
			return 3;
		} else if(!(strpos($strCondition,'雪') === false)) {
			return 13;
		} else if(!(strpos($strCondition,'雾') === false)) {
			return 18;
		} else if(!(strpos($strCondition,'尘') === false)) {
			return 18;
		} else {
			return 0;
		}
	}
	

	/**
	 *
	 *
	 * 组织天气接口用到的数据的数组
	 *
	 * @param string $rCityName        	
	 */
	function getWeather($rCityName) {
		$content = $this->getWeatherXml($rCityName);
		if (strlen ( $content ) > 700) {
			$xml = new SimpleXMLElement ( $content );
			$arr = $this->xmlToArray ( $xml );
			
			// file_put_contents('a.txt', print_r($arr,true));exit;
			$result = $arr ['string'];
			$weather ['city_name'] = $result [1];
			
			// 今天天气
			preg_match ( '/日 (.*)/', $result [7], $temp );
			if (strpos ( $temp [1], "转" )) {
				preg_match ( '/(.*)转/', $temp [1], $tt );
				$temp [1] = $tt [1];
			}
			$weather ['today_conditions'] ['condition'] = $temp [1];
			// 图标
			preg_match ( '/([0-9]*).gif/', $result [10], $temp );
			
			// ***********************************************************
			// 处理未知图标
			$temp_weather_type_today = $temp [1];
			if(strlen($temp_weather_type_today) == 0) {
				// 如果出现未知图标，则进行转换
				switch ($weather['today_conditions']['condition']) {
				case '小阵雨':
					// 转换为阵雨图标
					$temp_weather_type_today = 3;
				break;
				case '霾':
					// 转换为雾图标
					$temp_weather_type_today = 18;
				break;
				default:
					$temp_weather_type_today = $this->getWeatherTypeFromDesc($weather['today_conditions']['condition']);
				}
			}
			// ***********************************************************
			
			$weather ['today_conditions'] ['weather_type'] = $temp_weather_type_today;
			$weather ['today_conditions'] ['icon_uri'] = '';
			// 温度
			preg_match ( '/(.*)\/(.*)/', $result [8], $tmp_c );
			$weather ['today_conditions'] ['temp_c'] ['low'] = $tmp_c [1];
			$weather ['today_conditions'] ['temp_c'] ['high'] = $tmp_c [2];
			$temp_now = explode ( '；', $result [4] );
			$temp_arr = explode ( '：', $temp_now [0] );
			
			// preg_match('/([0-9]*)/',$temp_arr[2],$temp);
			$weather ['today_conditions'] ['temp_c'] ['now'] = $temp_arr [2];
			$weather ['today_conditions'] ['forecast'] = '';
			$weather ['today_conditions'] ['current_date_time'] = $result [3];
			$temp_arr = explode ( '：', $temp_now [2] );
			$weather ['today_conditions'] ['humidity'] = $temp_arr [1];
			$temp = explode ( '：', $temp_now [1] );
			// $temp = explode(' ', $temp[1]);
			$weather ['today_conditions'] ['wind_condition'] ['direction'] = $temp [1];
			$weather ['today_conditions'] ['wind_condition'] ['power'] = '';
			
			preg_match ( "/洗车指数：(.*宜洗车)，(.*)晾晒指数/s", $result [6], $temp );
			$weather ['today_conditions'] ['washcar_condition'] ['data'] = trim ( $temp [1] );
			$weather ['today_conditions'] ['washcar_condition'] ['desc'] = trim ( $temp [2] );
			
			// 明天天气
			preg_match ( '/日 (.*)/', $result [12], $temp );
			$weather ['tomorrow_conditions'] ['condition'] = $temp [1];
			preg_match ( '/([0-9]*).gif/', $result [15], $temp );
			
			// ***********************************************************
			// 处理未知图标
			$temp_weather_type_tomorrow = $temp [1];
			if(strlen($temp_weather_type_tomorrow) == 0) {
				// 如果出现未知图标，则进行转换
				switch ($weather['tomorrow_conditions']['condition']) {
				case '小阵雨':
					// 转换为阵雨图标
					$temp_weather_type_tomorrow = 3;
				break;
				case '霾':
					// 转换为雾图标
					$temp_weather_type_tomorrow = 18;
				break;
				default:
					$temp_weather_type_tomorrow = $this->getWeatherTypeFromDesc($weather['tomorrow_conditions']['condition']);
				}
			}
			// ***********************************************************
			
			
			$weather ['tomorrow_conditions'] ['weather_type'] = $temp_weather_type_tomorrow;
			$weather ['tomorrow_conditions'] ['icon_uri'] = '';
			preg_match ( '/(.*)\/(.*)/', $result [13], $tmp_c );
			$weather ['tomorrow_conditions'] ['temp_c'] ['low'] = $tmp_c [1];
			$weather ['tomorrow_conditions'] ['temp_c'] ['high'] = $tmp_c [2];
			$weather ['tomorrow_conditions'] ['wind_condition'] ['direction'] = $result [14];
			$weather ['tomorrow_conditions'] ['wind_condition'] ['power'] = '';
			$weather ['tomorrow_conditions'] ['washcar_condition'] ['data'] = '';
			$weather ['tomorrow_conditions'] ['washcar_condition'] ['desc'] = '';
			
			// 后天天气
			preg_match ( '/日 (.*)/', $result [17], $temp );
			$weather ['after_tomorrow_conditions'] ['condition'] = $temp [1];
			preg_match ( '/([0-9]*).gif/', $result [20], $temp );
			
			// ***********************************************************
			// 处理未知图标
			$temp_weather_type_after_tomorrow = $temp [1];
			if(strlen($temp_weather_type_after_tomorrow) == 0) {
				// 如果出现未知图标，则进行转换
				switch ($weather['after_tomorrow_conditions']['condition']) {
				case '小阵雨':
					// 转换为阵雨图标
					$temp_weather_type_after_tomorrow = 3;
				break;
				case '霾':
					// 转换为雾图标
					$temp_weather_type_after_tomorrow = 18;
				break;
				default:
					$temp_weather_type_after_tomorrow = $this->getWeatherTypeFromDesc($weather['after_tomorrow_conditions']['condition']);
				}
			}
			// ***********************************************************
			
			
			$weather ['after_tomorrow_conditions'] ['weather_type'] = $temp_weather_type_after_tomorrow;
			$weather ['after_tomorrow_conditions'] ['icon_uri'] = '';
			preg_match ( '/(.*)\/(.*)/', $result [18], $tmp_c );
			$weather ['after_tomorrow_conditions'] ['temp_c'] ['low'] = $tmp_c [1];
			$weather ['after_tomorrow_conditions'] ['temp_c'] ['high'] = $tmp_c [2];
			$weather ['after_tomorrow_conditions'] ['wind_condition'] ['direction'] = $result [19];
			$weather ['after_tomorrow_conditions'] ['wind_condition'] ['power'] = '';
			$weather ['after_tomorrow_conditions'] ['washcar_condition'] ['data'] = '';
			$weather ['after_tomorrow_conditions'] ['washcar_condition'] ['desc'] = '';
		}else{
			//如果获取失败，再走免费通道获取数据
			$weather = $this->getWeathterForFree($rCityName);
		}
		return $weather;
	}
	/**
	 * 免费接口
	 * //file_put_contents('free.txt',var_export(WeatherWebxml::getInstance()->getWeathterForFree('北京'),true));
	 * @param string $rCityName 城市名称
	 */
	public function getWeathterForFree($rCityName){
		$web_service_api = 'http://www.webxml.com.cn/WebServices/WeatherWebService.asmx/getWeatherbyCityName?theCityName='.urlencode($rCityName);

		$city_name = md5($rCityName);
		$absCacheFile = AP_PRIVATE_DATA_PATH . $city_name . '_rawdata_free.xml';
		$mtime = @filemtime($absCacheFile);
		$filesize = @filesize($absCacheFile);
		
		if (!file_exists($absCacheFile) || mktime() - $mtime > 21600 || $filesize<300 ) {
			$content = file_get_contents($web_service_api);
			if(strlen($content) > 300){
				file_put_contents($absCacheFile, $content);
			}
		}else{
			$content = file_get_contents($absCacheFile);
		}
		$xml = new SimpleXMLElement ( $content );
		$arr = $this->xmlToArray ( $xml );
		
		$result = $arr ['string'];
		$weather ['city_name'] = $result [1];
			
		// 今天天气
		preg_match ( '/日 (.*)/', $result [6], $temp );
		if (strpos ( $temp [1], "转" )) {
			preg_match ( '/(.*)转/', $temp [1], $tt );
			$temp [1] = $tt [1];
		}
		$weather ['today_conditions'] ['condition'] = $temp [1];
		// 图标
		preg_match ( '/([0-9]*).gif/', $result [8], $temp );
		$weather ['today_conditions'] ['weather_type'] = $temp [1];
		$weather ['today_conditions'] ['icon_uri'] = '';
		// 温度
		preg_match ( '/(.*)\/(.*)/', $result [5], $tmp_c );
		$weather ['today_conditions'] ['temp_c'] ['low'] = $tmp_c [1];
		$weather ['today_conditions'] ['temp_c'] ['high'] = $tmp_c [2];
		$temp_now = explode ( '；', $result [10] );
		$temp_arr = explode ( '：', $temp_now [0] );
			
		// preg_match('/([0-9]*)/',$temp_arr[2],$temp);
		$weather ['today_conditions'] ['temp_c'] ['now'] = $temp_arr [2];
		$weather ['today_conditions'] ['forecast'] = '';
		$weather ['today_conditions'] ['current_date_time'] = $result [4];
		$temp_arr = explode ( '：', $temp_now [2] );
		$weather ['today_conditions'] ['humidity'] = $temp_arr [1];
		$temp = explode ( '：', $temp_now [1] );
		// $temp = explode(' ', $temp[1]);
		$weather ['today_conditions'] ['wind_condition'] ['direction'] = $temp [1];
		$weather ['today_conditions'] ['wind_condition'] ['power'] = '';
			
		preg_match ( "/洗车指数：(.*宜洗车)，(.*)晾晒指数/s", $result [11], $temp );
		$weather ['today_conditions'] ['washcar_condition'] ['data'] = trim ( $temp [1] );
		$weather ['today_conditions'] ['washcar_condition'] ['desc'] = trim ( $temp [2] );
			
		// 明天天气
		preg_match ( '/日 (.*)/', $result [13], $temp );
		$weather ['tomorrow_conditions'] ['condition'] = $temp [1];
		preg_match ( '/([0-9]*).gif/', $result [15], $temp );
		$weather ['tomorrow_conditions'] ['weather_type'] = $temp [1];
		$weather ['tomorrow_conditions'] ['icon_uri'] = '';
		preg_match ( '/(.*)\/(.*)/', $result [12], $tmp_c );
		$weather ['tomorrow_conditions'] ['temp_c'] ['low'] = $tmp_c [1];
		$weather ['tomorrow_conditions'] ['temp_c'] ['high'] = $tmp_c [2];
		$weather ['tomorrow_conditions'] ['wind_condition'] ['direction'] = $result [14];
		$weather ['tomorrow_conditions'] ['wind_condition'] ['power'] = '';
		$weather ['tomorrow_conditions'] ['washcar_condition'] ['data'] = '';
		$weather ['tomorrow_conditions'] ['washcar_condition'] ['desc'] = '';
			
		// 后天天气
		preg_match ( '/日 (.*)/', $result [18], $temp );
		$weather ['after_tomorrow_conditions'] ['condition'] = $temp [1];
		preg_match ( '/([0-9]*).gif/', $result [20], $temp );
		$weather ['after_tomorrow_conditions'] ['weather_type'] = $temp [1];
		$weather ['after_tomorrow_conditions'] ['icon_uri'] = '';
		preg_match ( '/(.*)\/(.*)/', $result [17], $tmp_c );
		$weather ['after_tomorrow_conditions'] ['temp_c'] ['low'] = $tmp_c [1];
		$weather ['after_tomorrow_conditions'] ['temp_c'] ['high'] = $tmp_c [2];
		$weather ['after_tomorrow_conditions'] ['wind_condition'] ['direction'] = $result [19];
		$weather ['after_tomorrow_conditions'] ['wind_condition'] ['power'] = '';
		$weather ['after_tomorrow_conditions'] ['washcar_condition'] ['data'] = '';
		$weather ['after_tomorrow_conditions'] ['washcar_condition'] ['desc'] = '';
		
		return $weather;
	}
	/**
	 *
	 *
	 * xmlToArray
	 * 
	 * @param unknown_type $objects        	
	 */
	private function xmlToArray($objects) {
		$array = array ();
		$objects = ( array ) $objects;
		foreach ( $objects as $key => $object ) {
			if ($object instanceof SimpleXMLElement || is_array ( $object )) {
				$object = self::xmlToArray ( $object );
			}
			$array = array_merge ( $array, array (
					$key => $object 
				)
			);
		}
		return $array;
	}

}